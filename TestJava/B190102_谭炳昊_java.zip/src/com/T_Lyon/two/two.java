package com.T_Lyon.two;

import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

public class two {
    Set result = new HashSet();
    int x = 0;

    @Test
    public void main() {

        m();
        System.out.println(result.toString());
        System.out.println(x);
    }

    public void m() {
        int a = 10000;
        for (int i = 1; i < a; i++) {
            for (int j = 1; j < a; j++) {
                for (int k = max(i, j); k < a; k++) {
                    pd(i, j, k);
                }
            }
        }
    }

    public void pd(int i, int j, int k) {

        if (i * i + j * j == k * k) {
            x++;
            String a = i + "*" + i + "+" + j + "*" + j + "=" + k + "*" + k;
            result.add(a);
        }
    }

    public int max(int x, int y) {
        if (x > y) {
            return x;
        } else
            return y;
    }
}
