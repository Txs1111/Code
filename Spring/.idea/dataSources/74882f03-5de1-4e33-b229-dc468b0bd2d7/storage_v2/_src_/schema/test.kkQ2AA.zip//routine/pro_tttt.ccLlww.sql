create
    definer = root@localhost procedure pro_tttt()
begin
	declare continue handler for SQLEXCEPTION
	begin
		set @a='报错';
		select '异常了';
	end;
	select * from ttt;
	set @a = '被执行了';
end;

