create
    definer = root@localhost procedure pro_name(IN a int, OUT b int)
begin
	select a*a into b;
end;

