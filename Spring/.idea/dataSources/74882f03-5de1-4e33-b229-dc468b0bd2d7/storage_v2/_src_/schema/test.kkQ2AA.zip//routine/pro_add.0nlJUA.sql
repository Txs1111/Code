create
    definer = root@localhost procedure pro_add(IN a int, IN b int, OUT c int)
begin
select a+b into c;
end;

