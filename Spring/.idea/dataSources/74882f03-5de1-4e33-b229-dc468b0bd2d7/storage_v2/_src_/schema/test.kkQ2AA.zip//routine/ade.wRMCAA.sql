create
    definer = root@localhost procedure ade()
BEGIN
	#Routine body goes here...

END;

